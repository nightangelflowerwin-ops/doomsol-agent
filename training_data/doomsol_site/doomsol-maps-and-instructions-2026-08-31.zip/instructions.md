# DoomSol map instructions and descriptions

Source: https://doomsol.io/

## E1M4 — Command Control

- Game: DOOM
- Chapter: EPISODE 1 : KNEE-DEEP IN THE DEAD
- Par: 3:00
- Co-designer: None listed

One of only two Episode 1 levels credited to Petersen. Knee-Deep in the Dead is otherwise Romero and Tom Hall territory, the shareware episode that sold the game, which makes these two the quiet start of the largest level-design credit in DOOM.





## E1M8 — Phobos Anomaly

- Game: DOOM
- Chapter: EPISODE 1 : KNEE-DEEP IN THE DEAD
- Par: 0:30*
- Co-designer: None listed
- Tag: BOSS

The end of the shareware episode, and for millions of people in 1993 the end of the only DOOM they owned. Beat it and the floor drops you into Hell.





## E2M1 — Deimos Anomaly

- Game: DOOM
- Chapter: EPISODE 2 : THE SHORES OF HELL
- Par: 1:30
- Co-designer: Tom Hall

Seven sections stitched together by pairs of teleporters that fling you long distances across the map. It is genuinely easy to lose your bearings, so the automap is not optional. The base still looks like a base, right up until the geometry stops making sense.

Notes: Only the second DOOM level with a key you do not need in order to finish it: the red key opens a secret room and nothing else. Bobby Prince's track is inspired by AC/DC's "Big Gun".



## E2M2 — Containment Area

- Game: DOOM
- Chapter: EPISODE 2 : THE SHORES OF HELL
- Par: 1:30
- Co-designer: Tom Hall
- Tag: THE CRATE MAZE

The huge northern warehouse is a crate maze modelled on the warehouse at the end of Raiders of the Lost Ark, built to suggest enormous space without overtaxing the engine. The layout is so open that the first shot you fire tends to bring imps from every direction at once.

Notes: Fans voted it the best of all the original id Software maps in the 2015 April Agitation tournament. It is the first DOOM level with no former humans, and it holds the most secrets of any Ultimate DOOM level (12). Tom Hall calls it his favourite DOOM map, and his crate maze later inspired the crates in LucasArts' Jedi Knight as an homage.



## E2M3 — Refinery

- Game: DOOM
- Chapter: EPISODE 2 : THE SHORES OF HELL
- Par: 1:30
- Co-designer: Tom Hall

Industrial guts. Narrow catwalks over nukage, blind corners, and a layout that keeps folding back onto itself.

Notes: Per Petersen, Tom Hall built the rising-and-falling pillar room specifically to test the engine's new features, and textured the pillars in metal. When Petersen reworked the level he switched them to hellgrowth "for dramatic effect." Early versions ran as E1M3 in the DOOM 0.3, 0.4 and 0.5 alphas.



## E2M4 — Deimos Lab

- Game: DOOM
- Chapter: EPISODE 2 : THE SHORES OF HELL
- Par: 2:00
- Co-designer: Tom Hall

Doomwiki calls it "arguably more difficult than some of the levels which follow it." It is open enough that a firefight in the first room wakes imps on the far side of the map, and loaded with trap-released monster groups and disguised crushing ceilings you can lure things under to save ammo.

Notes: It contains eleven rockets, twenty-two on the easiest and hardest skills, and no rocket launcher.



## E2M5 — Command Center

- Game: DOOM
- Chapter: EPISODE 2 : THE SHORES OF HELL
- Par: 1:30
- Co-designer: None listed
- Tag: SECRET EXIT TO E2M9

Sandy solo. The nerve centre of the moon base rebuilt as a hostile machine, all control rooms that funnel you into ambushes, and the level hiding the secret exit to Fortress of Mystery.

Notes: The red-over-green switch texture used for the exit appears nowhere else in the entire game. Eight rockets, again no launcher. The PlayStation and Saturn versions are cut down so heavily they lose the secret exit altogether.



## E2M6 — Halls of the Damned

- Game: DOOM
- Chapter: EPISODE 2 : THE SHORES OF HELL
- Par: 6:00
- Co-designer: None listed
- Tag: HIS INTERVIEW LEVEL / THE FAKE EXIT

This is the level Sandy built at his job interview. Romero sat him down at DoomEd, asked him to make something, and hired him off the result. It has the longest par time in the episode, a dark maze, and a notorious fake exit.

Notes: The fake-exit idea was Romero's; he gave Petersen free rein on the execution. Petersen also says per-sector light levels were added to the engine while he was building this map, which is why it has such large lighting jumps between areas. E2M6 is a fossil of the engine's own development.



## E2M7 — Spawning Vats

- Game: DOOM
- Chapter: EPISODE 2 : THE SHORES OF HELL
- Par: 4:00
- Co-designer: Tom Hall

The last man-made complex in the game, and effectively an amalgamation of every base that came before it: container warehouse welded to computer complex. Where the things come from.

Notes: E2M7 was the first level ever started for DOOM. Early versions appear as E1M1 in alphas 0.3 and 0.4. It began as the DOOM Bible's "Hangar 2," and the alpha's start room was a control room where marines play cards. That room ended up holding a single cacodemon.



## E2M8 — Tower of Babel

- Game: DOOM
- Chapter: EPISODE 2 : THE SHORES OF HELL
- Par: 0:30*
- Co-designer: None listed
- Tag: BOSS : THE FIRST CYBERDEMON

The first Cyberdemon fight in history. You start in a small octagonal room. Four switches on a central pillar raise stairs behind walls of crucified barons, then the doors shut and you are in a huge open arena with it.

Notes: The name inverts Genesis 11. In the Bible it is a path to Heaven built by man and destroyed by God; in DOOM it is a path to Hell built by demons and destroyed by a man. On the Episode 2 intermission screen the tower is animated being built as you advance. It is the first non-secret DOOM level with no imps at all.



## E2M9 — Fortress of Mystery

- Game: DOOM
- Chapter: EPISODE 2 : THE SHORES OF HELL
- Par: 2:50
- Co-designer: None listed
- Tag: SECRET / HIS OWN FAVOURITE

A pure concept level: one room full of Barons of Hell, one room full of Cacodemons, and almost nothing else. Open both doors, let them argue, and walk out carrying every weapon in the game except the BFG.

Notes: Petersen considers this his best DOOM level design, calling it "a little gem of creature and unit balancing," and says it was the first level to use monster infighting as an integral gameplay concept. On the intermission map the fortress is not drawn until E2M5 clears, then fades in, then vanishes after completion, leaving only a blood splat.



## E3M1 — Hell Keep

- Game: DOOM
- Chapter: EPISODE 3 : INFERNO
- Par: 1:30
- Co-designer: None listed

No more pretending. Episode 3 drops the science fiction entirely: a small, mean, ugly little fortress, deliberately small and mean and ugly. An eye switch raises the starting platform into the open, then a red wall, a door, and two skull switches. Left opens, right closes.

Notes: E3M9 Warrens is built directly on this level's bones. Most console ports substitute a different Hell Keep entirely.



## E3M2 — Slough of Despair

- Game: DOOM
- Chapter: EPISODE 3 : INFERNO
- Par: 0:45
- Co-designer: None listed
- Tag: THE HAND

Open the automap and the floor plan is a human hand: five finger-corridors radiating from a palm, with the blue skull key at the end of one of them. You have been walking around inside a giant clawing at the floor of Hell the whole time.

Notes: The hand reading is an observation about the geometry, not a statement by Petersen. The name likely nods to the Slough of Despond in Bunyan's Pilgrim's Progress, and "slough" is pronounced "slew." Speedrun: UV speed 0:12 by Marijo Sedlić, Christmas Day 2002.



## E3M3 — Pandemonium

- Game: DOOM
- Chapter: EPISODE 3 : INFERNO
- Par: 1:30
- Co-designer: Tom Hall

Named for the capital of Hell and Satan's palace in Milton's Paradise Lost. Marble, blood, and a central structure that keeps opening onto worse things.

Notes: The music is based on Slayer's "Behind the Crooked Cross." The supercharge in the central lava pit is one of the best places in the game to trigger DOOM's rare "ouch face." It was originally conceived as the DOOM Bible's Tei Tenga base Control Center hub.



## E3M4 — House of Pain

- Game: DOOM
- Chapter: EPISODE 3 : INFERNO
- Par: 2:30
- Co-designer: None listed
- Tag: THE ORGANS

Per Petersen, the layout is roughly based on the positioning of human organs, and the lungs and stomach are still clearly visible on the automap. The zoologist building a level out of an anatomy plate.

Notes: Sourced to Dan Pinchbeck, DOOM: Scarydarkfast (2013). The name may reference the "House of Pain" chant in H.G. Wells' The Island of Dr. Moreau. Design detail: the switches raise item platforms only if the crusher above them has not been triggered first.



## E3M5 — Unholy Cathedral

- Game: DOOM
- Chapter: EPISODE 3 : INFERNO
- Par: 1:30
- Co-designer: Tom Hall (uncredited)
- Tag: ATTRIBUTION DISPUTED

The infamous teleporter courtyard: a hall ringed with teleporters that shuffle you between corners, releasing monsters every time.

Notes: Credited to Petersen, but he says otherwise: "Tom did 90% of this map… Because he left before we had all of the different treasures and weapons and monsters, I had to add all that to it. But I kept his basic idea of 'you have to go teleporting around'." He takes part of the blame anyway for not fixing it. Romero disputes Hall's involvement.



## E3M6 — Mt. Erebus

- Game: DOOM
- Chapter: EPISODE 3 : INFERNO
- Par: 1:30
- Co-designer: Tom Hall
- Tag: SECRET EXIT TO E3M9 / THE ROCKET JUMP

Bright, open, lava-filled, and the level hiding the secret exit to Warrens, sealed inside a blue box you were supposed to reach by taking the invulnerability and rocket-jumping into it. This is effectively where the rocket jump was born.

Notes: Romero: "The only way you are supposed to reach the secret switch was by getting the invincibility, blasting a rocket into the wall so you would fly backwards into the box. We found out early on that it was possible to flip the switch from outside, so Sandy made the walls thicker." Romero credits the idea to Tom Hall. Erebus is a region of the Greek underworld, but the volcano points at Mount Erebus in Antarctica, the setting of Lovecraft's At the Mountains of Madness. A pointed coincidence for the man who wrote Call of Cthulhu.



## E3M7 — Limbo

- Game: DOOM
- Chapter: EPISODE 3 : INFERNO
- Par: 2:45
- Co-designer: Tom Hall

Labelled "Gate to Limbo" on the intermission screen, and named for Hell's first circle in Canto IV of Dante's Divine Comedy. A huge room with a semicircular platform around a great circle of blood, and an underground blood maze holding the red skull key.

Notes: A primitive version was E2M1 of DOOM 0.5, originally the starting level of the DOOM Bible's "Episode 2: Lost in Hell." It cannot be loaded in 0.5 at all, because it references texture indexes that do not exist yet.



## E3M8 — Dis

- Game: DOOM
- Chapter: EPISODE 3 : INFERNO
- Par: 0:30*
- Co-designer: None listed
- Tag: BOSS : THE SPIDER MASTERMIND

The Spider Mastermind, and the end of the original DOOM. A four-lobed clover-leaf arena with almost all the ammo sitting on a raised walkway you can only reach by the steps north of the central building, or by walking it the instant you arrive. Doomwiki, dryly: "This lack of ammo provides extra challenge."

Notes: Named for the City of Dis in Dante's Inferno and the Roman god of the underworld. Replaced by Tower of Babel in the PlayStation and Saturn ports.



## E3M9 — Warrens

- Game: DOOM
- Chapter: EPISODE 3 : INFERNO
- Par: 2:15
- Co-designer: None listed
- Tag: SECRET

A brilliant troll. It is Hell Keep rebuilt, and it plays near-identically right up to the point where E3M1 would end. There the exit turns out to be fake and you walk the whole thing again in a far nastier version, with extra rooms, extra enemies and two skull keys. A designer using your own memory against you.

Notes: After the fake exit the monster count is identical on every skill level, because difficulty scaling only applies to the E3M1-lookalike section. A level called "The Warrens" appears in id's earlier Catacomb 3D.



## MAP01 — Entryway

- Game: DOOM II
- Chapter: DOOM II : HELL ON EARTH
- Par: 0:30
- Co-designer: None listed
- Tag: THE FIRST THING YOU SEE

The most-played map in DOOM history: the default first level, the universal deathmatch and speedrun warm-up, and the slot that everyone's very first WAD replaces. The most-played thirty seconds Sandy ever built.

Notes: UV speed record 0:04.97 by Aleksey Kamenev. An early version released in 2015 has an entirely different starting area, an anteroom of computer kiosks and a short hallway before you reach the familiar triangular-staircase overlook.



## MAP07 — Dead Simple

- Game: DOOM II
- Chapter: DOOM II : HELL ON EARTH
- Par: 2:00
- Co-designer: American McGee
- Tag: PETERSEN DENIES MAKING THIS MAP

One courtyard. Hit the switch, the walls drop, kill every Mancubus. More walls drop revealing Arachnotrons; kill them all and the exit opens. So clean an idea that "Dead Simple clone" is now a documented category of fan map.

Notes: The credit is shared with American McGee, but Petersen disputes it outright: "Frankly I don't remember doing any part of 'Dead Simple'. Thought it was all American McGee's." It is listed here with the dispute attached. The map introduces the Mancubus and the Arachnotron, and its wave mechanic is hardcoded to the MAP07 slot in the engine, which is why every mapper who fills slot 7 inherits it. The backpack at the start is actually ten backpacks stacked on top of each other.



## MAP08 — Tricks and Traps

- Game: DOOM II
- Chapter: DOOM II : HELL ON EARTH
- Par: 2:00
- Co-designer: None listed
- Tag: OPEN THE DOOR. STEP BACK.

A hub of doors, and behind every door a different gag. Doomwiki singles it out for encounters "where monster infighting and teleportation have significant roles," and compares it directly to E2M9 as a level built around a gimmick rather than looks. Open the door. Step aside. Let them sort it out.

Notes: It introduces the Pain Elemental. All four shoot-to-reveal secrets share a common visual tell, so finding one hands you the rest.



## MAP09 — The Pit

- Game: DOOM II
- Chapter: DOOM II : HELL ON EARTH
- Par: 4:30
- Co-designer: None listed
- Tag: THE MUSIC IS NAMED AFTER HIM

A sludge pit around a plus-shaped central platform. Progression is a chain of lifts and switches that raise chunks of floor to unlock higher corridors, punctuated by walls that open behind you.

Notes: Bobby Prince's track for this level is called "Into Sandy's City." Doomwiki calls it "an obvious reference to him."



## MAP10 — Refueling Base

- Game: DOOM II
- Chapter: DOOM II : HELL ON EARTH
- Par: 1:30
- Co-designer: Tom Hall

A rescued DOOM 1 map. Tom Hall started it for the first game, where it appeared as E1M6 in DOOM 0.5, it did not make the cut, and Petersen finished it for DOOM II. Big, non-linear, easy to get lost in.

Notes: It holds two DOOM II records: the most secrets of any level (18) and the most enemies on Ultra-Violence and Nightmare (279).



## MAP12 — The Factory

- Game: DOOM II
- Chapter: DOOM II : HELL ON EARTH
- Par: 2:30
- Co-designer: None listed

An outdoor industrial complex of discrete brick buildings you circle from the outside. Wall platforms rise as you advance through the first building to spring imp ambushes, and mancubi wait in alcoves.





## MAP13 — Downtown

- Game: DOOM II
- Chapter: DOOM II : HELL ON EARTH
- Par: 2:30
- Co-designer: None listed
- Tag: THE ARROW

A city: a grid of individually enterable skyscrapers inside a walled downtown, in an engine that was never meant to draw a skyline. One of DOOM II's signature Hell-on-Earth statements, and the home of the most argued-about floor decal in the game. Look at the bottom of the automap.





## MAP16 — Suburbs

- Game: DOOM II
- Chapter: DOOM II : HELL ON EARTH
- Par: 2:30
- Co-designer: None listed
- Tag: HIS HOUSE AND HIS FATHER'S

Two of the buildings in this level are real. The south-centre building is Sandy Petersen's own house; the northernmost is his father's. He built where he lived, and where he grew up, into DOOM II, and then let demons into both.





## MAP18 — The Courtyard

- Game: DOOM II
- Chapter: DOOM II : HELL ON EARTH
- Par: 2:30
- Co-designer: None listed

It opens with a joke: the first door has no switch. You have to punch it, chainsaw it or shoot it open. The courtyard proper is a sprint across open ground to the staircase before the demons box you in.

Notes: The main theme of the music is often likened to the verse riff of Pantera's "This Love."



## MAP19 — The Citadel

- Game: DOOM II
- Chapter: DOOM II : HELL ON EARTH
- Par: 3:30
- Co-designer: None listed

A moated fortress reached by a bridge from an outlying building, one of the more architecturally legible Petersen maps. The exterior is the hard part; by the time you are inside, the level has already taken its cut.

Notes: The supercharge inside the citadel is a teleport trap.



## MAP21 — Nirvana

- Game: DOOM II
- Chapter: DOOM II : HELL ON EARTH
- Par: 4:00
- Co-designer: None listed
- Tag: NOT THE BAND

Named for the Buddhist concept: freedom from passion and desire, the end of the cycle of rebirth. Teleporter-chained chambers, a revenant ambush at the first pad, and a triangular four-switch platform that raises a staircase. No official secrets.





## MAP23 — Barrels o' Fun

- Game: DOOM II
- Chapter: DOOM II : HELL ON EARTH
- Par: 3:00
- Co-designer: None listed
- Tag: DO NOT SHOOT THE FIRST BARREL

Doomwiki, deadpan: "notable for containing large amounts of barrels, as the name suggests." It opens with a flat sprint down a barrel-packed hallway before a mancubus sets off the chain reaction behind you, then runs the same trick again with chaingunners, then hands you a room of pain elementals.

Notes: Game designer Chris Crawford analysed this level's gameplay in Next Generation, May 1996. The music is heavily inspired by Alice in Chains' "Them Bones" and is the only DOOM II track reused in all three IWADs.



## MAP24 — The Chasm

- Game: DOOM II
- Chapter: DOOM II : HELL ON EARTH
- Par: 2:30
- Co-designer: None listed
- Tag: THE ONE EVERYONE ARGUES ABOUT

Thin walkways over a drop into nukage, in a game with no jump button and no ledge grab. DOOM II's most notorious balance-beam level, its most divisive map, and one nobody who played it has ever forgotten.

Notes: Petersen has said the map came out of a nightmare in which he was navigating a network of walkways and narrow bridges over deep, dark chasms. A teleporter chain lets you skip the blue key entirely, though you still need the red one to exit.



## MAP27 — Monster Condo

- Game: DOOM II
- Chapter: DOOM II : HELL ON EARTH
- Par: 5:30
- Co-designer: None listed
- Tag: THE D&D JOKE

A library, of all things: bookcase-lined rooms crammed with monsters and traps, and Arch-Viles raising everything you have already killed. Domestic horror in a game about a space marine.

Notes: Two sources, both from Petersen. First, a recurring nightmare about a library with a secret room containing something horrible; he wanted "to throw as many weird monsters and traps as possible" into it. Second, the name is a Dungeons & Dragons in-joke. Players mocking incoherent dungeon design ("you just have a bunch of rooms of monsters") would call it "just a monster condo." A direct line from his tabletop career into DOOM.



## MAP28 — The Spirit World

- Game: DOOM II
- Chapter: DOOM II : HELL ON EARTH
- Par: 7:00
- Co-designer: None listed

The last real level before the finale. Pure Hell geometry, no pretence of Earth left, and the difficulty finally taking the gloves off.

Notes: Tied for the longest par time in DOOM II. It is the only level designed by id Software featuring more than one Spiderdemon, on Hurt Me Plenty and above, alongside arachnotrons in the same enormous room.



## MAP30 — Icon of Sin

- Game: DOOM II
- Chapter: DOOM II : HELL ON EARTH
- Par: 3:00*
- Co-designer: None listed
- Tag: FINAL BOSS

The end of DOOM II. A wall-sized demon face endlessly firing spawn cubes, stepped elevator platforms you ride upward, and one exposed brain you have to put a rocket into at a very precise angle. Sandy built the last room in DOOM.

Notes: Use idclip to walk into the head and you find John Romero's severed head impaled on a spike, and shooting it is what actually ends the level. The boss's arcane chant, played backwards, is Romero's distorted voice saying "To win the game you must kill me, John Romero."



## MAP31 — Wolfenstein

- Game: DOOM II
- Chapter: DOOM II : HELL ON EARTH
- Par: 2:00
- Co-designer: None listed
- Tag: SECRET / WOLF3D REPLICA

Secret level, reached from MAP15. id Software's previous game rebuilt inside this one: grey stone, blue uniforms, and enemies that shout in German. Doomwiki is precise about it. This is a replica of the first map of Wolfenstein 3D, not an original design.

Notes: It introduces the Wolfenstein SS. It is built at double scale, because id used the 128×128 textures from the Atari Jaguar Wolfenstein port rather than the DOS originals. The music is not from Wolf3D at all; it is from the prequel Spear of Destiny. The DOOM source still contains commented-out code for horizontally sliding doors, so Wolf-style doors were planned and abandoned.



## MAP32 — Grosse

- Game: DOOM II
- Chapter: DOOM II : HELL ON EARTH
- Par: 0:30
- Co-designer: None listed
- Tag: SUPER SECRET / WOLF3D REPLICA

The super secret level, hidden inside the secret level. Based on the final level of Wolfenstein 3D's shareware episode, the Hans Grösse boss fight, with a Cyberdemon bursting through the door instead, and then a room of four hanging Commander Keens.

Notes: "Grosse" is a misspelling of "Grösse," an obsolete form of "Größe," meaning size or height. Killing all four Keens raises the panel behind them to reveal the exit switch, a mechanic that works in any DOOM II WAD containing Keen figures. The French release calls it "Le Massacre."


